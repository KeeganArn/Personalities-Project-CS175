<?php
// Connect to MySQL database
$servername = "localhost";
$username = "root"; 
$password = "";     
$dbname = "survey"; 

$conn = new mysqli($servername, $username, $password, $dbname);

// Check for a database connection error
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get data from the form
    $name = $_POST['name'] ?? '';
    $experience = $_POST['experience'] ?? '';
    $suggestions = $_POST['suggestions'] ?? '';

    // Sanitize input to prevent SQL injection
    $name = $conn->real_escape_string($name);
    $experience = $conn->real_escape_string($experience);
    $suggestions = $conn->real_escape_string($suggestions);

    // Insert data into the database
    $sql = "INSERT INTO surveyinfo (name, experience, suggestions) VALUES ('$name', '$experience', '$suggestions')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => $conn->error]);
    }

    // Close the database connection
    $conn->close();
}
?>
