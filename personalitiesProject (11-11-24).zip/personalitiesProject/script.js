// Show survey when the user tries to leave the page
window.addEventListener("beforeunload", function (e) {
    // Prevent leaving by showing the modal
    document.getElementById('surveyModal').style.display = "block";

    // Prevent default action for the unload event
    e.preventDefault();
    e.returnValue = ''; // This is required for the dialog to appear
});

// Close the survey modal without submitting
document.getElementById('closeSurvey').addEventListener('click', function () {
    document.getElementById('surveyModal').style.display = "none";
});

// Handle the form submission
document.getElementById('surveyForm').addEventListener('submit', function (e) {
    e.preventDefault(); // Prevent the default form submission

    // Gather the form data
    const name = document.getElementById('name').value;
    const experience = document.getElementById('experience').value;
    const suggestions = document.getElementById('suggestions').value;

    // Send data to the backend (via AJAX)
    const formData = new FormData();
    formData.append('name', name);
    formData.append('experience', experience);
    formData.append('suggestions', suggestions);

    fetch('submit_survey.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Thank you for your feedback!");
        } else {
            alert("There was an error. Please try again.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Something went wrong.');
    });

    // Hide the modal after submission
    document.getElementById('surveyModal').style.display = "none";
});
