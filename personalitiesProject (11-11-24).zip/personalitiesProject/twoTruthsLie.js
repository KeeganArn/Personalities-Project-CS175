const statements = [
    { text: "I have traveled internationally", isLie: false },
    { text: "I once met a celebrity.", isLie: false },
    { text: "I have never eaten sushi.", isLie: true },
    { text: "I can speak three languages.", isLie: true },
    { text: "I played highschool football", isLie: false },
    { text: "I once ran a marathon.", isLie: true },
];

function startGame() {
    const randomStatements = statements.sort(() => 0.5 - Math.random()).slice(0, 3);
    const gameDiv = document.getElementById("game");
    gameDiv.innerHTML = ""; // Clear previous statements

    randomStatements.forEach(statement => {
        const statementDiv = document.createElement("div");
        statementDiv.innerText = statement.text;

        const truthButton = document.createElement("button");
        truthButton.innerText = "Truth";
        truthButton.onclick = () => checkAnswer(statement.isLie, false);

        const lieButton = document.createElement("button");
        lieButton.innerText = "Lie";
        lieButton.onclick = () => checkAnswer(statement.isLie, true);

        statementDiv.appendChild(truthButton);
        statementDiv.appendChild(lieButton);
        gameDiv.appendChild(statementDiv);
    });
}

function checkAnswer(isLie, guessedLie) {
    const resultText = guessedLie === isLie 
        ? "Correct! That's the lie." 
        : "Oops! That's a truth.";
    
    document.getElementById("result").innerText = resultText;
    setTimeout(() => {
        document.getElementById("result").innerText = ""; // Clear result after a short delay
        startGame(); // Start a new game
    }, 2000); // 2 seconds delay
}

// Start the game on page load
window.onload = startGame;
