function correct()
{
    alert("CORRECT")
}
function incorrect()
{
    alert("INCORRECT")
}