
const surveyModal = document.getElementById("surveyModal");
const closeSurveyButton = document.getElementById("closeSurvey");


function checkScrollPosition() {
    
    const scrollPosition = window.scrollY;
    
    
    const documentHeight = document.documentElement.scrollHeight;
    
    
    const windowHeight = window.innerHeight;
    
    
    if (scrollPosition + windowHeight >= documentHeight) {
        
        surveyModal.style.display = "block";
    }
}


window.addEventListener("scroll", checkScrollPosition);


closeSurveyButton.addEventListener('click', function () {
    surveyModal.style.display = "none";
});


document.getElementById('surveyForm').addEventListener('submit', function (e) {
    e.preventDefault(); 

   
    const name = document.getElementById('name').value;
    const experience = document.getElementById('experience').value;
    const suggestions = document.getElementById('suggestions').value;

   
    const formData = new FormData();
    formData.append('name', name);
    formData.append('experience', experience);
    formData.append('suggestions', suggestions);

    fetch('submit_survey.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Thank you for your feedback!");
        } else {
            alert("There was an error. Please try again.");
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Something went wrong.');
    });

    
    surveyModal.style.display = "none";
});
