function showFor(optionId) {
    const sections = document.querySelectorAll('.content');
    sections.forEach(section => section.style.display = 'none');

    const selectedSection = document.getElementById(optionId);
    if (selectedSection) {
        selectedSection.style.display = 'block';
    }
}