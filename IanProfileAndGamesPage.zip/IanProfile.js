function check1()
{
    str1="Wooster"

    var str2=document.getElementById("city").value;
    if (str1.toLowerCase() == str2.toLowerCase())
        alert("Correct!")
    else
        alert("Incorrect, try again!")
}

function check2()
{
    str3="Cybersecurity"
    str4="Computer Science"
    var str5=document.getElementById("major").value;
    if (str3.toLowerCase() == str5.toLowerCase() || str4.toLowerCase() == str5.toLowerCase()) 
        alert("Correct!")
    else
        alert("Incorrect, try again!")
}

function check3()
{
    str6="Invincible"
    var str7=document.getElementById("series").value;
    if (str6.toLowerCase() == str7.toLowerCase()) 
        alert("Correct!")
    else
        alert("Incorrect, try again!")
}